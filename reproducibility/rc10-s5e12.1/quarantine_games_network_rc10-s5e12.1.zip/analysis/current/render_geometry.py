#!/usr/bin/env python3
"""Reproduce measured-grid spatial-minus-RRG epidemic contrast heatmaps.

No simulation, interpolation or modification of upstream records is performed.
The source ledger must be the archived, SHA-256-verified HGR v2.1 repair table.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
import numpy as np
import pandas as pd


SOURCE_SHA256 = "f9e190283c9fa7185bed094f6956d959c6eda085cd58c05343d3b5fd5a23827d"
MEASUREMENTS = ("R_inf/N", "T_epi", "I_max/N")
PAIRS = (
    ("honeycomb", "rr_k3", "Honeycomb - RRG3", 3),
    ("square", "rr_k4", "Square - RRG4", 4),
    ("triangular", "rr_k6", "Triangular - RRG6", 6),
    ("truncated_square_488", "rr_k3", "4.8.8 - RRG3", 3),
    ("kagome", "rr_k4", "Kagome - RRG4", 4),
)
OBS_TITLES = {
    "R_inf/N": r"$\Delta R_\infty$",
    "T_epi": r"$\Delta T_{\mathrm{epi}}$",
    "I_max/N": r"$\Delta I_{\max}$",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def reconstruct(source: Path) -> tuple[pd.DataFrame, dict]:
    observed_hash = sha256(source)
    if observed_hash != SOURCE_SHA256:
        raise RuntimeError(f"Unexpected source hash: {observed_hash}")
    data = pd.read_csv(source)
    expected_topologies = {item for a, b, _, _ in PAIRS for item in (a, b)}
    data = data.loc[
        data["observable"].isin(MEASUREMENTS)
        & data["topology"].isin(expected_topologies)
        & data["beta_n"].between(1.5, 15.0)
        & data["delta"].between(1, 20)
        & data["grid_role"].isin(("GLOBAL_GRID", "GLOBAL_GRID_TOPUP"))
    ].copy()
    if set(data["topology"].unique()) != expected_topologies:
        raise AssertionError("Unexpected source topology set")
    if data.duplicated(["topology", "observable", "beta_n", "delta"]).any():
        raise AssertionError("Duplicated source cells")
    assert len(data) == 8 * 3 * 560, len(data)
    assert data.groupby(["topology", "observable"]).size().eq(560).all()
    assert data["beta_n"].nunique() == 28 and data["delta"].nunique() == 20
    assert data["censored"].eq(0).all()
    assert data["protocol"].nunique() == 1
    assert data["n"].isin((128, 256)).all()
    assert data.loc[data["topology"].str.startswith("rr_"), "graph_count"].eq(16).all()
    assert data.loc[~data["topology"].str.startswith("rr_"), "graph_count"].eq(1).all()

    columns = ["beta_n", "delta", "observable", "mean", "n", "population", "grid_role", "ci95_low", "ci95_high"]
    results = []
    for spatial, rrg, label, degree in PAIRS:
        left = data.loc[data["topology"].eq(spatial), columns]
        right = data.loc[data["topology"].eq(rrg), columns]
        merged = left.merge(right, on=["beta_n", "delta", "observable"], validate="one_to_one", suffixes=("_spatial", "_rrg"))
        if len(merged) != 3 * 560:
            raise AssertionError(f"Incomplete overlap in {label}: {len(merged)}")
        merged.insert(0, "pair", label)
        merged.insert(1, "degree", degree)
        merged.insert(2, "spatial_topology", spatial)
        merged.insert(3, "rrg_topology", rrg)
        merged["delta_mean"] = merged["mean_spatial"] - merged["mean_rrg"]
        merged["rrg_graph_count"] = 16
        results.append(merged)
    derived = pd.concat(results, ignore_index=True)
    if derived["delta_mean"].isna().any() or len(derived) != 5 * 3 * 560:
        raise AssertionError("Invalid derived contrast grid")
    derived = derived.sort_values(["degree", "pair", "observable", "delta", "beta_n"], kind="stable")
    qa = {
        "source_sha256": observed_hash,
        "source_file": source.name,
        "selected_topology_count": int(data["topology"].nunique()),
        "selected_observable_count": len(MEASUREMENTS),
        "source_selected_rows": int(len(data)),
        "source_selected_grid_cell_count_per_topology_observable": 560,
        "derived_rows": int(len(derived)),
        "pairs": [p[2] for p in PAIRS],
        "beta_n": sorted(map(float, data["beta_n"].unique())),
        "delta": sorted(map(float, data["delta"].unique())),
        "source_n_values": sorted(map(int, data["n"].unique())),
        "censored_rows": int(data["censored"].sum()),
        "rrg_graphs_per_cell": 16,
        "uncertainty": "No inferential intervals for the differences; stored arm-wise intervals must not be subtracted.",
    }
    return derived, qa


def summarize(derived: pd.DataFrame) -> pd.DataFrame:
    items = []
    for (pair, obs), group in derived.groupby(["pair", "observable"], sort=False):
        values = group["delta_mean"].to_numpy()
        items.append({
            "pair": pair,
            "observable": obs,
            "cells": len(values),
            "positive_cells": int((values > 0).sum()),
            "negative_cells": int((values < 0).sum()),
            "zero_cells": int((values == 0).sum()),
            "positive_fraction": float((values > 0).mean()),
            "negative_fraction": float((values < 0).mean()),
            "minimum": float(values.min()),
            "median": float(np.median(values)),
            "maximum": float(values.max()),
        })
    return pd.DataFrame(items)


def plot_grid(derived: pd.DataFrame, selected: list[str], output: Path, prefix: str, font_scale: float = 1.0) -> None:
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 10.5 * font_scale,
        "axes.titleweight": "semibold",
        "axes.edgecolor": "#424242",
        "xtick.color": "#333333",
        "ytick.color": "#333333",
        "pdf.fonttype": 42,
    })
    nrows = len(selected)
    fig, axs = plt.subplots(nrows, 3, sharex=True, sharey=True, figsize=(14.4, 3.05 * nrows + 1.65), layout="constrained")
    if nrows == 1:
        axs = axs[np.newaxis, :]
    fig.get_layout_engine().set(h_pad=0.13, w_pad=0.14, hspace=0.07, wspace=0.02)

    vmax = {obs: float(derived.loc[derived.observable.eq(obs), "delta_mean"].abs().max()) for obs in MEASUREMENTS}
    beta = sorted(derived.beta_n.unique())
    delta = sorted(derived.delta.unique())
    dx = float(beta[1] - beta[0]); dy = float(delta[1] - delta[0])
    for i, pair in enumerate(selected):
        for j, obs in enumerate(MEASUREMENTS):
            ax = axs[i, j]
            subset = derived.loc[derived.pair.eq(pair) & derived.observable.eq(obs)]
            pivot = subset.pivot(index="delta", columns="beta_n", values="delta_mean").reindex(index=delta, columns=beta)
            if pivot.isna().any().any() or pivot.shape != (20, 28):
                raise AssertionError(f"Invalid plotted matrix {pair}/{obs}")
            image = ax.imshow(
                pivot.to_numpy(),
                cmap="RdBu",
                norm=TwoSlopeNorm(vmin=-vmax[obs], vcenter=0, vmax=vmax[obs]),
                origin="lower",
                interpolation="nearest",
                aspect="auto",
                extent=(min(beta) - dx/2, max(beta) + dx/2, min(delta) - dy/2, max(delta) + dy/2),
                rasterized=True,
            )
            ax.set_xticks([2, 4, 6, 8, 10, 12, 14])
            ax.set_yticks([2, 5, 10, 15, 20])
            ax.tick_params(labelsize=9 * font_scale, length=3)
            if j == 0:
                ax.set_ylabel(pair + "\n" + r"$\delta$", fontsize=10.5 * font_scale, labelpad=7)
            if i == nrows - 1:
                ax.set_xlabel(r"$\beta_N$", fontsize=11 * font_scale)
            if i == 0:
                axs[0, j]._color_image = image

    for j, obs in enumerate(MEASUREMENTS):
        cb = fig.colorbar(axs[0, j]._color_image, ax=axs[:, j], location="top", orientation="horizontal", fraction=0.029, pad=0.025, shrink=0.90)
        cb.ax.xaxis.set_ticks_position("bottom")
        cb.ax.xaxis.set_label_position("top")
        cb.set_label(OBS_TITLES[obs], fontsize=14 * font_scale, labelpad=8)
        cb.ax.tick_params(labelsize=8.4 * font_scale)

    # Keep the plotting field uncluttered. Sampling and uncertainty caveats
    # are documented next to the deliverable rather than over the colorbars.
    fig.savefig(output / f"{prefix}.png", dpi=220, facecolor="white")
    fig.savefig(output / f"{prefix}.pdf", facecolor="white")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ledger", type=Path, help="Original accepted ledger (SHA256 validated)")
    parser.add_argument("--derived", type=Path, help="Reproduce plotting from a prior derived CSV")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--si-font-scale", type=float, default=1.0,
                        help="Optional typography-only scale for the 3x3 SI figure (default 1.0)")
    args = parser.parse_args()
    if not 1.0 <= args.si_font_scale <= 2.0:
        parser.error("--si-font-scale must lie between 1.0 and 2.0")
    if (args.ledger is None) == (args.derived is None):
        parser.error("Pass exactly one of --ledger or --derived")
    args.output.mkdir(parents=True, exist_ok=True)
    if args.ledger:
        derived, qa = reconstruct(args.ledger)
        derived.to_csv(args.output / "measured_geometry_contrast_cells.csv", index=False, float_format="%.16g")
        (args.output / "reconstruction_qa.json").write_text(json.dumps(qa, indent=2, ensure_ascii=False) + "\n")
    else:
        derived = pd.read_csv(args.derived)
        assert len(derived) == 5 * 3 * 560
    summarize(derived).to_csv(args.output / "contrast_summary.csv", index=False, float_format="%.12g")
    plot_grid(derived, [p[2] for p in PAIRS[:3]], args.output, "main_3x3_spatial_minus_rrg",
              font_scale=args.si_font_scale)
    plot_grid(derived, [p[2] for p in PAIRS], args.output, "atlas_5x3_all_pairs")


if __name__ == "__main__":
    main()
