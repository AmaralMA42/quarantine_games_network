#!/usr/bin/env python3
"""Render the independent G1R N=66240 Figure 11 with the RC9.5 V14's exact topology identity palette.

This does not modify the frozen manuscript. Uses measured coordinates only.
Usage: python render_fig11_new_n66240.py DATA.csv OUTPUT_DIR
"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ORDER = ['truncated_square_488','honeycomb','kagome','square','triangular']
STYLE = {
    'truncated_square_488': ('4.8.8','#6F3FA0','8','rr_k3'),
    'honeycomb': ('Honeycomb','#E69F00','h','rr_k3'),
    'kagome': ('Kagome','#CC79A7','D','rr_k4'),
    'square': ('Square','#0072B2','s','rr_k4'),
    'triangular': ('Triangular','#D55E00','^','rr_k6'),
}
REFERENCE_NAME={'rr_k3':'RRG3','rr_k4':'RRG4','rr_k6':'RRG6'}
BETAS = [1.01,1.8,2.8,4,5,6,7,8,10,12,14,17,20]


def make_figure(source,outdir):
    df=pd.read_csv(source)
    d=df[df.N==66240].copy()
    if len(d)!=65:
        raise ValueError(f'Expected 65 measured contrasts, got {len(d)}')
    if set(d.spatial)!=set(ORDER) or sorted(set(d.beta_n))!=BETAS:
        raise ValueError('Topology/beta mismatch against G1R preregistration')
    if d.duplicated(['N','beta_n','spatial']).any():
        raise ValueError('Duplicated coordinate')
    if not np.allclose(d.R_spatial-d.R_RRG, d.delta_Rinf, rtol=0,atol=1e-12):
        raise ValueError('Invalid contrast arithmetic')
    if not ((d.ci95_low<=d.delta_Rinf)&(d.delta_Rinf<=d.ci95_high)).all():
        raise ValueError('Invalid CI ordering')
    if set(d.n_spatial)!={256} or set(d.n_rrg_graphs)!={16} or set(d.n_rrg_per_graph)!={16}:
        raise ValueError('Unexpected sampling contract')
    plt.rcdefaults()
    plt.rcParams.update({
        'font.family':'STIXGeneral', 'mathtext.fontset':'stix', 'font.size':8,
        'axes.labelsize':9, 'axes.linewidth':0.65, 'lines.linewidth':0.85,
        'pdf.fonttype':42, 'xtick.labelsize':7, 'ytick.labelsize':8,
        'axes.spines.top':False, 'axes.spines.right':False,
        'svg.fonttype':'none','savefig.facecolor':'white'
    })
    fig,ax=plt.subplots(figsize=(7.1,3.8))
    fig.subplots_adjust(top=.8,left=.1,right=.985,bottom=.15)
    handles=[]
    for key in ORDER:
        lab,color,marker,ref=STYLE[key]
        g=d[d.spatial==key].sort_values('beta_n')
        x=g.beta_n.to_numpy(dtype=float)
        y=g.delta_Rinf.to_numpy(dtype=float)
        yerr=np.vstack([y-g.ci95_low.to_numpy(),g.ci95_high.to_numpy()-y])
        ax.plot(x,y,color=color,marker=marker,mfc=color,mec=color,ms=3,lw=.9,zorder=3)
        ax.errorbar(x,y,yerr=yerr,fmt='none',ecolor=color,elinewidth=.60,capsize=1.4,capthick=.60,zorder=4)
        handles.append(Line2D([],[],color=color,marker=marker,mfc=color,mec=color,label=lab+' - '+REFERENCE_NAME[ref],lw=.9,ms=4))
    ax.axhline(0,color='.2',ls='--',lw=.7)
    ax.set(xlabel=r'$\beta_N$',ylabel=r'$\Delta^{\mathrm{geom}}R_\infty$',xlim=(.5,20.4),xticks=[1,5,10,15,20],ylim=(-.55,.3))
    ax.grid(alpha=.13,lw=.4)
    ax.set_axisbelow(True)
    seq=[handles[i] for col in range(3) for i in range(col,len(handles),3)]
    fig.legend(handles=seq,ncol=3,frameon=False,fontsize=7,loc='upper center')
    outdir.mkdir(parents=True,exist_ok=True)
    base=outdir/'FIG11_G1R_N66240_CANONICAL_STYLE_CANDIDATE'
    for ext,kwargs in [('.pdf',{}),('.svg',{}),('.png',{'dpi':220})]:
        fig.savefig(str(base)+ext,**kwargs)
    plt.close(fig)
    return str(base)

if __name__=='__main__':
    if len(sys.argv)!=3: raise SystemExit('usage: render_fig11_new_n66240.py DATA.csv OUTPUT_DIR')
    print(make_figure(Path(sys.argv[1]),Path(sys.argv[2])))
