"""Attach, verify and restore the current measured-data publication materials."""
from pathlib import Path
import csv,hashlib,io,json,shutil,subprocess,sys,zipfile

ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def specification():return json.loads((ROOT/'CURRENT_PUBLICATION.json').read_text())
def prepare(archive,check_only=False):
    archive=Path(archive); spec=specification()
    if sha(archive)!=spec['sha256']:raise ValueError('Current data archive SHA-256 mismatch')
    with zipfile.ZipFile(archive) as z:
        names=z.namelist()
        if len(names)!=len(set(names)):raise ValueError('Duplicate archive member')
        manifest=z.read('MANIFEST_SHA256.csv'); rows=list(csv.DictReader(io.StringIO(manifest.decode('utf-8'))))
        if set(names)!={r['path'] for r in rows}|{'MANIFEST_SHA256.csv'}:raise ValueError('Manifest coverage mismatch')
        for row in rows:
            p=ROOT/row['path']
            if not p.resolve().is_relative_to(ROOT.resolve()) or Path(row['path']).parts[0] not in {'current','fig9_update','fig10_update'}:raise ValueError('Unsafe archive path')
            data=z.read(row['path'])
            if len(data)!=int(row['bytes']) or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('Data binding mismatch: '+row['path'])
            if not check_only and p.exists() and p.read_bytes()!=data:raise FileExistsError(p)
        if not check_only:
            for row in rows:
                p=ROOT/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(row['path']))
            (ROOT/'current/MANIFEST_SHA256.csv').write_bytes(manifest)
    return {'status':'PASS_CURRENT_DATA_ARCHIVE','verified_files':len(rows),'attached':not check_only}

def verify():
    with (ROOT/'current/MANIFEST_SHA256.csv').open(encoding='utf-8') as stream:rows=list(csv.DictReader(stream))
    for row in rows:
        p=ROOT/row['path']
        if sha(p)!=row['sha256']:raise ValueError('Changed data file: '+row['path'])
    assets=json.loads((ROOT/'current/FIGURE_ASSETS.json').read_text());assert len(assets)==17
    with (ROOT/'current/inputs/fig8_five_landmarks_n15_s5.csv').open() as stream:landmarks=list(csv.DictReader(stream))
    assert len(landmarks)==40 and len({(r['topology'],r['landmark']) for r in landmarks})==40
    assert len({r['topology'] for r in landmarks})==8
    from .recurrence import verify as recurrence_verify
    return {'status':'PASS_CURRENT_DATA','bound_files':len(rows),'figure_assets':17,'landmark_coordinates':40,'recurrence':recurrence_verify()}

def restore():
    receipt=verify(); assets=json.loads((ROOT/'current/FIGURE_ASSETS.json').read_text())
    for a in assets:
        src=ROOT/a['reference'];assert sha(src)==a['sha256']
        dest=ROOT/'restored'/a['document']/a['name'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
        assert sha(dest)==a['sha256']
    receipt.update(status='PASS_RESTORED_ACCEPTED_VECTORS',restored_assets=17,independent_redrawing=False,new_simulations=0)
    (ROOT/'qa').mkdir(exist_ok=True);(ROOT/'qa/CURRENT_RESTORE.json').write_text(json.dumps(receipt,indent=2)+'\n')
    return receipt

def render(figure):
    receipt=verify();out=ROOT/'redrawn';out.mkdir(exist_ok=True)
    if figure=='10':
        from .recurrence import render as draw
        result=draw(out/'FIG10_RECURRENCE_DEPTH.pdf')
    elif figure=='11':
        subprocess.run([sys.executable,str(ROOT/'analysis/current/render_reach.py'),str(ROOT/'current/campaigns/fig11_g1r/FIG11_G1R_N66240_65_MEASURED_CONTRASTS_CI95.csv'),str(out)],check=True)
        result={'measured_contrasts':65}
    elif figure=='S5':
        subprocess.run([sys.executable,str(ROOT/'analysis/current/render_geometry.py'),'--derived',str(ROOT/'current/campaigns/geometry_atlas_derived/measured_geometry_contrast_cells.csv'),'--output',str(out),'--si-font-scale','1.5'],check=True)
        result={'derived_cells':8400}
    else:raise ValueError(figure)
    receipt.update(status='PASS_CURRENT_DEDICATED_RENDER',figure=figure,result=result,new_simulations=0)
    (ROOT/'qa').mkdir(exist_ok=True);(ROOT/'qa'/('CURRENT_RENDER_'+figure+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    return receipt
