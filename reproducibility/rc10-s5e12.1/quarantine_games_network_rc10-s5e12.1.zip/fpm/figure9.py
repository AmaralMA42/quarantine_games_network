"""Append the supplied symbol legend to the preserved vector plot; no analysis."""
from pathlib import Path
import copy
import hashlib
import json
import math
from pypdf import PdfReader,PdfWriter,Transformation
from pypdf.generic import ContentStream,FloatObject,DictionaryObject,NameObject

ROOT=Path(__file__).resolve().parents[1]
UPDATE=ROOT/'fig9_update'


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def corrected_footer(template):
    reader=PdfReader(template);page=copy.copy(reader.pages[0])
    stream=ContentStream(page.get_contents(),reader);ops=stream.operations
    assert [op for args,op in ops[:3]]==[b'q',b'Do',b'Q']
    # The supplied footer is independent of the original plot form at ops 0..2.
    assert ops[52][1]==b'RG' and list(map(float,ops[52][0]))==[.8,.47,.65]
    assert [op for args,op in ops[46:51]]==[b'm',b'l',b'l',b'l',b'l']
    cx=(238.85459+233.76343)/2;cy=26.;c=math.sqrt(.5)
    # The pink Kagome path was an unrotated square; rotate its own vertices.
    for i in range(46,51):
        args,op=ops[i];x,y=map(float,args);dx=x-cx;dy=y-cy
        ops[i]=([FloatObject(round(cx+c*(dx-dy),7)),FloatObject(round(cy+c*(dx+dy),7))],op)
    assert [op for args,op in ops[4:10]]==[b'm',b'c',b'c',b'c',b'c',b'h']
    # The original 4.8.8 points are regular octagons, not circular markers.
    cx=122.31701;cy=26.;s=3.1;t=s*(math.sqrt(2)-1)
    vertices=[(-t,-s),(-s,-t),(-s,t),(-t,s),(t,s),(s,t),(s,-t),(t,-s)]
    polygon=[([FloatObject(round(cx+x,7)),FloatObject(round(cy+y,7))],b'm' if j==0 else b'l')
             for j,(x,y) in enumerate(vertices)]+[([],b'h')]
    ops[4:10]=polygon
    stream.operations=ops[3:]
    page.replace_contents(stream)
    resources=DictionaryObject(dict(page['/Resources']))
    resources.pop(NameObject('/XObject'),None)
    page[NameObject('/Resources')]=resources
    return page


def compose(original,template,output):
    original=Path(original);template=Path(template);output=Path(output)
    base=PdfReader(original).pages[0];footer=corrected_footer(template)
    w,h=float(base.mediabox.width),float(base.mediabox.height)
    assert abs(w-511.2)<1e-6 and abs(h-370.8)<1e-6
    assert abs(float(footer.mediabox.width)-w)<1e-6
    assert abs(float(footer.mediabox.height)-h-34)<1e-6
    writer=PdfWriter();writer.pdf_header=b'%PDF-1.4'
    page=writer.add_blank_page(width=w,height=h+34)
    page.merge_transformed_page(base,Transformation().translate(tx=0,ty=34),expand=False)
    page.merge_page(footer,over=True,expand=False)
    writer.add_metadata({'/Title':'Effects of strategy updating and risk information',
                         '/Creator':'Vector composition from preserved plot and symbol legend'})
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('wb') as f:writer.write(f)
    return dict(output=str(output),sha256=sha(output),plot_recomputed=False,
                legend_rows=2,legend_marker_corrections=['Kagome: diamond','4.8.8: octagon'])


def build(output=None):
    return compose(UPDATE/'sources/FIG9_ORIGINAL.pdf',UPDATE/'sources/FIG9_SUPPLIED_LEGEND.pdf',
                   Path(output) if output else UPDATE/'generated/FIG9_SYMBOL_LEGEND.pdf')


def verify(include_generated=False):
    config=json.loads((UPDATE/'INPUTS.json').read_text(encoding='utf-8'))
    for entry in config['files']:
        assert sha(UPDATE/entry['path'])==entry['sha256'],entry['path']
    if include_generated:
        assert sha(UPDATE/'generated/FIG9_SYMBOL_LEGEND.pdf')==config['reference_sha256']
    return dict(status='PASS_FIG9_INPUTS',source_records=40,new_simulations=0)
