"""Publication-sized Figure 10 from verified current observations and intervals."""
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from ..recurrence import verify, TOPOLOGIES

STYLES={
    'truncated_square_488':('4.8.8','#713FA9','o'),
    'honeycomb':('Honeycomb','#DD9300','h'),
    'kagome':('Kagome','#CE76A5','D'),
    'square':('Square','#0077B8','s'),
    'triangular':('Triangular','#E36C13','^'),
    'rr_k3':('RRG3','#999999','o'),
    'rr_k4':('RRG4','#666666','o'),
    'rr_k6':('RRG6','#222222','o'),
    'well_mixed':('Finite WM (CTMC)','#111111','x'),
}


def draw(ctx):
    checked=verify(ctx.root)
    points=pd.read_csv(ctx.root/'data/FIG10_N15_PROBABILITIES.csv')
    fig,axes=plt.subplots(1,2,figsize=(6.35,3.75))
    fig.subplots_adjust(left=.10,right=.985,bottom=.27,top=.92,wspace=.27)
    handles={};segments=[]
    for ax,panel in zip(axes,('A','B')):
        for topology in TOPOLOGIES:
            d=points[(points.panel==panel)&(points.topology==topology)].sort_values('m')
            label,color,marker=STYLES[topology]
            x=d['m'].to_numpy(dtype=float); y=d['probability'].to_numpy(dtype=float)
            lower=d['lo'].to_numpy(dtype=float); upper=d['hi'].to_numpy(dtype=float)
            err=ax.errorbar(x,y,yerr=[y-lower,upper-y],
                label=label,color=color,marker=marker,markersize=3.8,lw=1.0,
                elinewidth=.65,capsize=1.8,capthick=.65,zorder=6 if topology=='well_mixed' else 3)
            handles[topology]=err.lines[0]
            actual=err.lines[2][0].get_segments()
            np.testing.assert_allclose(err.lines[0].get_xdata(),x,rtol=0,atol=0)
            np.testing.assert_allclose(err.lines[0].get_ydata(),y,rtol=0,atol=0)
            for row,segment in zip(d.itertuples(),actual):
                np.testing.assert_allclose(segment,[[row.m,row.lo],[row.m,row.hi]],rtol=0,atol=1e-14)
                segments.append(dict(panel=panel,topology=topology,m=int(row.m),lo=float(row.lo),hi=float(row.hi)))
        ax.set(xlim=(1.87,5.12),ylim=(-.025,1.055),xticks=[2,3,4,5],yticks=np.linspace(0,1,6))
        ax.set_xlabel(r'$m$',fontsize=10,labelpad=2)
        ax.set_ylabel(r'$P(n_p\geq m)$',fontsize=10,labelpad=3)
        ax.tick_params(labelsize=8.2,width=.65,length=3,pad=2)
        ax.set_title(panel,loc='left',fontweight='bold',fontsize=10,pad=5)
        ax.grid(alpha=.13,lw=.4);ax.set_axisbelow(True)
    legends=[]
    for row,start,end in ((0,0,5),(1,5,9)):
        names=TOPOLOGIES[start:end]
        legends.append(fig.legend([handles[t] for t in names],[STYLES[t][0] for t in names],
            loc='lower center',bbox_to_anchor=(.53,.105-.064*row),ncol=len(names),
            frameon=False,fontsize=8,handlelength=1.7,handletextpad=.55,columnspacing=1.0))
    fig.canvas.draw(); renderer=fig.canvas.get_renderer()
    boxes=[leg.get_window_extent(renderer) for leg in legends]
    assert not boxes[0].overlaps(boxes[1]),'Legend rows overlap'
    assert len(segments)==72
    ctx.save(fig,'FIG10_RECURRENCE_DEPTH',points.to_dict('records'))
    receipt=dict(**checked,plotted_probability_points=72,verified_errorbar_segments=segments,
        legend_rows=2,legend_labels=[5,4],figure_size_in=[6.35,3.75],tick_font_pt=8.2,
        legend_font_pt=8,colors_and_markers='retained from supplied Figure 10',
        displayed_interval_endpoints_changed=False)
    (ctx.root/'qa/FIG10_RENDER.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    return receipt
