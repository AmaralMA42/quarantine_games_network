"""Verify and replay the current recurrence-depth observations; no simulation."""
from collections import Counter, defaultdict
from pathlib import Path
import csv
import hashlib
import io
import json
import math
import zipfile

ROOT = Path(__file__).resolve().parents[1]
UPDATE = ROOT / 'fig10_update'
TOPOLOGIES = ('truncated_square_488','honeycomb','kagome','square','triangular',
              'rr_k3','rr_k4','rr_k6','well_mixed')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_rows(path):
    with Path(path).open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def intervals(x, n, rrg):
    from scipy.optimize import brentq
    from scipy.stats import beta
    if not rrg:
        return (0. if x == 0 else float(beta.ppf(.025,x,n-x+1)),
                1. if x == n else float(beta.ppf(.975,x+1,n-x)))
    q=x/n; c=math.log(40)/n
    if q==0: return 0., -math.expm1(-c)
    if q==1: return math.exp(-c), 1.
    def f(p): return q*math.log(q/p)+(1-q)*math.log((1-q)/(1-p))-c
    return float(brentq(f,1e-13,q)), float(brentq(f,q,1-1e-13))


def verify(update=UPDATE, include_generated=False):
    update=Path(update)
    spec=json.loads((update/'INPUTS.json').read_text(encoding='utf-8'))
    for row in spec['inputs']:
        path=update/row['path']
        assert path.is_file() and path.stat().st_size==row['bytes'] and sha(path)==row['sha256'], row['path']
    points=read_rows(update/'data/FIG10_N15_PROBABILITIES.csv')
    runs=read_rows(update/'data/RUN_LEVEL_PEAK_COUNTS.csv')
    assert len(points)==72 and len(runs)==1152
    assert len({r['run_fingerprint'] for r in runs})==1152
    groups=defaultdict(list)
    for r in runs: groups[r['panel'],r['topology']].append(r)
    assert len(groups)==18
    expected={(r['panel'],r['topology'],int(r['m'])):r for r in points}
    assert len(expected)==72
    for panel in ('A','B'):
        for topology in TOPOLOGIES:
            rows=groups[panel,topology]
            assert len(rows)==64
            graphs=Counter(r['graph_sha256'] for r in rows)
            assert len(graphs)==(8 if topology.startswith('rr_') else 1)
            assert set(graphs.values())==({8} if topology.startswith('rr_') else {64})
            assert set(graphs)=={r['graph_sha256'] for r in groups['B' if panel=='A' else 'A',topology]}
            previous=64
            for m in (2,3,4,5):
                row=expected[panel,topology,m]
                x=sum(int(r['n_robust_peaks'])>=m for r in rows)
                assert int(row['successes'])==x and int(row['n'])==64
                assert abs(float(row['probability'])-x/64)<1e-14 and x<=previous
                previous=x
                lo,hi=intervals(x,64,topology.startswith('rr_'))
                assert abs(lo-float(row['lo']))<1e-12 and abs(hi-float(row['hi']))<1e-12
    for entry in spec.get('reference_assets',[]):
        assert sha(update/entry['path'])==entry['sha256']
    if include_generated:
        for entry in spec.get('reference_assets',[]):
            assert sha(ROOT/entry['generated'])==entry['sha256']
    return dict(status='PASS_FIG10_DATA',trajectories=1152,points=72,
                intervals_recomputed=72,rrg_design='8 graphs x 8 epidemics per panel',new_simulations=0)


def robust_count(trace, population, beta_n, delta):
    import numpy as np
    from scipy.signal import find_peaks
    parts=trace.split(';')
    assert parts[0].startswith('0:') and parts[-1].startswith('F:')
    counts=np.fromiter((int(p.split(':')[1]) for p in parts[:-1]),dtype=float)
    votes=[]
    for window in (5,9,17):
        smoothed=np.convolve(counts,np.ones(window)/window,mode='same')
        for prominence in (.05,.10,.20):
            for spacing in (12,24,40):
                peaks,_=find_peaks(smoothed,height=max(1.,population/(beta_n*delta)),
                                  prominence=max(1.,prominence*float(smoothed.max())),distance=spacing)
                votes.append(len(peaks))
    return min(8,sorted(votes)[5])


def replay(archive, update=UPDATE):
    update=Path(update); archive=Path(archive)
    spec=json.loads((update/'INPUTS.json').read_text(encoding='utf-8'))
    assert sha(archive)==spec['raw_archive_sha256']
    expected={r['run_fingerprint']:r for r in read_rows(update/'data/RUN_LEVEL_PEAK_COUNTS.csv')}
    seen=set()
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for member in z.infolist():
            if '/results/' not in member.filename or not member.filename.endswith('.tsv'): continue
            with z.open(member) as f:
                for r in csv.DictReader(io.TextIOWrapper(f,encoding='utf-8'),delimiter='\t'):
                    key=r['run_fingerprint']; assert key not in seen; seen.add(key)
                    target=expected[key]
                    assert int(r['censored'])==0 and r['stop_reason']=='absorbed_I0'
                    n=robust_count(r['trace_v2'],int(r['population']),float(r['beta_n']),float(r['delta']))
                    assert n==int(target['n_robust_peaks']),r['run_id']
            print(f'Existing trajectory replay: {len(seen)}/1152',flush=True)
    assert seen==set(expected)
    return dict(status='PASS_FIG10_TRACE_REPLAY',trajectories=len(seen),differences=0,new_simulations=0)


def render(output=None):
    from .visuals.style import PlotContext
    from .visuals.recurrence import draw
    with PlotContext(UPDATE,'standard','main') as ctx:
        if output is not None:
            output=Path(output); ctx.output=output.parent; ctx.output.mkdir(parents=True,exist_ok=True)
            assert output.stem=='FIG10_RECURRENCE_DEPTH'
        result=draw(ctx)
    return result
