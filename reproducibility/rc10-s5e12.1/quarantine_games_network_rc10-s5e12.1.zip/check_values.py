"""Check numerical statements against the measured tables shipped with the article."""
import csv
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def read(name, sep=","):
    with (ROOT/name).open(encoding="utf-8-sig",newline="") as f:
        return list(csv.DictReader(f,delimiter=sep))
def campaign(part,suffix):
    p,=list((ROOT/"current/campaigns"/part).rglob(suffix))
    return read(p)
def check(condition,message):
    if not condition:raise ValueError(message)
r=read("tables/fig2/square_g00_r00_adaptive.tsv","\t")[0]
check((int(r["ever_infected_count"]),int(r["population"]))==(1384,16384),"Fig 2, reach at extinction")
a=read("tables/fig2/rr_k4_g01_r01_adaptive.tsv","\t")[0]
b=read("tables/fig2/rr_k4_g01_r01_frozen.tsv","\t")[0]
check(all(a[k]==b[k] for k in ["population","graph_sha256","q_init_seed","i_init_seed","dynamic_seed","delta","beta_n"]),"Fig 2 paired design")
checked={"Fig 2":{"square_reach_at_extinction":[1384,16384],"RRG4_pair_shared_seeds":True}}
pairs=campaign("fig4_g3g5_workpack","BETA8_MATCHED_DEGREE.csv")
check(len(pairs)==5 and all(float(p["spatial_peak"])<float(p["rrg_peak"]) and float(p["spatial_duration"])>float(p["rrg_duration"]) for p in pairs),"Fig 4 degree pairs")
tri=next(p for p in pairs if p["spatial"]=="triangular")
check(float(tri["spatial_peak"])<0.5*float(tri["rrg_peak"]) and float(tri["spatial_duration"])>2*float(tri["rrg_duration"]),"Fig 4 triangular")
wm=[r for r in read("current/inputs/fig4_values.csv") if r["system"]=="well_mixed"]
check(bool(wm) and all((r["population"],r["n"])==("4096","16") for r in wm),"Fig 4 finite well-mixed")
extra=campaign("fig4_g3g5_workpack","G3_G5_NEW_CELL_SUMMARIES_95CI.csv")
newcells={(p["system"],p["beta_n"]) for p in extra}
check(len(newcells)==40,"Fig 4 added conditions")
checked["Fig 4"]={"degree_pairs":len(pairs),"additional_conditions":len(newcells),"well_mixed_n":16,"well_mixed_N":4096}
old={x["topology"]:x for x in campaign("fig7_n19_workpack","P0_FIG7_ACCEPTED_REFERENCE_LOCK_N18_PLUS_N19_EXISTING.csv") if x["log2N_nominal"]=="18"}
new={x["topology"]:x for x in campaign("fig7_n19_workpack","P4_N19_EIGHT_NETWORK_CROSSINGS_WIDTHS_BOOTSTRAP.csv")}
check(new.keys()==old.keys() and len(new)==8,"Fig 7 sizes")
drop=[100*(1-float(new[t]["W"])/float(old[t]["W"])) for t in old]
shift=[100*abs(float(new[t]["beta50"])/float(old[t]["beta50"])-1) for t in old]
check(19.0<min(drop)<21.0 and 27<max(drop)<29 and max(shift)<0.21,"Fig 7 narrowing or shift")
checked["Fig 7"]={"percent_width_reduction_range":[min(drop),max(drop)],"largest_abs_midpoint_shift_percent":max(shift)}
land=read("current/inputs/fig8_five_landmarks_n15_s5.csv")
group={}
for p in land:group.setdefault(p["topology"],{})[p["landmark"]]=float(p["beta_n"])
check(len(land)==40 and len(group)==8 and all(len(v)==5 for v in group.values()),"Fig 8 design")
check(all(d["establishment_N15"]<d["payoff_parity_50"]<d["duration_grid_max"]<d["reach_valley"] and 8<=d["reach_valley"]<=40 for d in group.values()),"Fig 8 measured order")
checked["Fig 8"]={"networks":8,"coordinates":40,"RRG6_measured_reach_min_beta":group["rr_k6"]["reach_valley"]}
runs=read("fig10_update/data/RUN_LEVEL_PEAK_COUNTS.csv")
check(len(runs)==1152 and len({r["run_id"] for r in runs})==1152,"Fig 10 sampling")
cols=["n_robust_peaks","n_robust_peaks_edgepad"]
thresholds=read("current/inputs/FIG10_THRESHOLD_COUNTS_PRIMARY_AND_EDGE_PADDING.csv")
allcounts={}
for p in thresholds:
    rr=[r for r in runs if r["panel"]==p["panel"] and r["topology"]==p["topology"]]
    hits=[sum(int(r[k])>=int(p["m"]) for r in rr) for k in cols]
    check(len(rr)==64 and hits==[int(p["primary_successes"]),int(p["endpoint_padding_successes"])],"Fig 10 threshold table")
    allcounts[(p["panel"],p["topology"],p["m"])]=hits
expected={("A","rr_k3","2"):[47,1],("A","rr_k4","4"):[42,16],("A","rr_k6","4"):[56,56],("B","triangular","2"):[57,57],("B","rr_k6","2"):[20,20]}
check(all(allcounts[k]==val for k,val in expected.items()),"Fig 10 manuscript counts")
changed=sum(r[cols[0]]!=r[cols[1]] for r in runs)
check(changed==479,"Fig 10 boundary sensitivity")
checked["Fig 10"]={"runs":1152,"changed_counts":changed,"verified_threshold_rows":len(thresholds),"reported_counts":{"/".join(k):v for k,v in expected.items()}}
geo=campaign("fig11_g1r","FIG11_G1R_N66240_65_MEASURED_CONTRASTS_CI95.csv")
check(len(geo)==65 and {p["N"] for p in geo}=={"66240"},"Fig 11 65 cells")
check(all(abs(float(p["R_spatial"])-float(p["R_RRG"])-float(p["delta_Rinf"]))<1e-10 for p in geo),"Fig 11 differences")
uncertain=[p["spatial"] for p in geo if float(p["beta_n"])==10 and float(p["ci95_low"])<=0<=float(p["ci95_high"])]
negative=[p for p in geo if float(p["beta_n"])==12 and float(p["ci95_high"])<0]
check(set(uncertain)=={"truncated_square_488","triangular"} and len(negative)==5,"Fig 11 intervals")
checked["Fig 11"]={"measured_contrasts":65,"unresolved_beta10":uncertain,"negative_beta12":len(negative)}
grid=campaign("geometry_atlas_derived","measured_geometry_contrast_cells.csv")
cells=[p for p in grid if p["spatial_topology"]=="triangular" and float(p["beta_n"])==6 and float(p["delta"])==8]
check(len(cells)==3 and all(p["population_spatial"]==p["population_rrg"]=="16384" and p["n_spatial"]==p["n_rrg"]=="256" and p["rrg_graph_count"]=="16" for p in cells),"S5 cell design")
val={p["observable"]:[float(p["mean_spatial"]),float(p["mean_rrg"])] for p in cells}
check([round(100*x,1) for x in val["R_inf/N"]]==[83.6,70.6] and [round(x,1) for x in val["T_epi"]]==[63.9,39.8] and [round(100*x,2) for x in val["I_max/N"]]==[4.62,11.87],"S5 contrasts")
checked["Fig S5"]={"means_triangular_then_RRG6":val,"per_system_n":256,"graphs_RRG6":16}
check(sum(int(r["n"]) for r in read("tables/S3/PRIMARY_832_COUNTS.csv"))==832,"S3 single-introduction classifications")
checked["Fig S3"]={"same_histories_classified_at_three_cutoffs":832}
if __name__=="__main__":print(json.dumps(checked,indent=2))
