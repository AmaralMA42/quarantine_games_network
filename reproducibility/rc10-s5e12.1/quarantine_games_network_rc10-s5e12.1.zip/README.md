# Quarantine Games reviewer materials
## Quarantine Games on Networks: Beyond Epidemic Establishment
Marco Antonio Amaral · 19 November 2026

The article and its Supplementary Information use 11 main figures and five supplementary figures. Figure 5 consists of two vector files. The included data archive carries measured results, records of individual epidemics for the recurrence comparison, statistical summaries and the 17 reference figure assets. Additional small tables for other figures are in the tables directory. The figure index maps every displayed figure to its input and procedure.

## Start in an empty directory
Extract this ZIP, then run the commands below in the directory containing main.py. Python 3.12 and the exact dependency versions are listed in requirements.txt. The data are already included.

    python -m venv .venv

Activate the environment with .venv/Scripts/activate on Windows or source .venv/bin/activate in a POSIX shell. The pinned packages in requirements.txt cover the commands below. The broader historical environment, including optional software for earlier workflows, is recorded in requirements-historical.txt. Then run:

    python -m pip install -r requirements.txt
    python main.py prepare-current --archive data/quarantine_games_current_data_v1.0.0.zip --check-only
    python main.py prepare-current --archive data/quarantine_games_current_data_v1.0.0.zip
    python main.py restore-current
    python check_values.py
    python main.py render-current --figure 10
    python main.py render-current --figure 11
    python main.py render-current --figure S5

The first check verifies the nested archive and its file hashes. Restored figures appear under restored/main and restored/si. They match the figure files in the article sources byte for byte. The three dedicated renderers produce new files in redrawn/ from the supplied epidemic peak counts or measured cell tables. Some also produce technical companion plots. The Fig. 11 intervals are the archived hierarchical bootstrap intervals. The S5 colors are differences of means. Neither command reruns epidemics. PDF metadata and fonts may differ between independent renderings.

## Finding evidence
Open docs/FIGURE_INDEX.csv for a map by published figure number. Some historical filenames use previous numbering. The standard-library script check_values.py checks the outcomes illustrated in Figs. 2, 4, 7, 8, 10, 11, S3 and S5 and prints the numerical results. For Fig. 2 the selected square run records final cumulative reach and time series of prevalence and protection. For Fig. 10 both endpoint conventions are available for the same 1,152 epidemic histories. For Fig. 11 and S5 the tables give the population and ensemble represented by each contrast.

docs/SCIENTIFIC_METHODS.md records the simulation protocols, uncertainty estimates, sampling limitations and earlier controls. The additional 288 fixed-strategy histories are a separate historical ensemble documented there. The 1,152 Figure 10 histories are the ensemble represented by the current recurrence figure. For historical reconstruction, DATA_BUNDLE.json and ARTICLE_UPDATE.json give the public inputs, versions and hashes. The archive included here suffices for all commands above.

The original code and software documentation use the MIT license. The original scientific data, tables and figures use CC BY 4.0. See LICENSE, LICENSES/ and LICENSING.md.
